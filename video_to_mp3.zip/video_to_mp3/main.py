from tkinter import*
from tkinter import filedialog
import moviepy
from moviepy import VideoFileClip
import os
from PIL import Image, ImageTk                                                                              
root=Tk()
root.title("Mp3 Converter")
root.geometry("711x400")
root.resizable(False,False)

image=ImageTk.PhotoImage(Image.open("back1.jpg"))
image_label=Label(root, image=image)
image_label.place(x=0,y=0)

def openfile():
    global file_path
    file_path=filedialog.askopenfilename(initialdir=os.getcwd(),title="select video",
                                         filetype=(('Video File','*.WEMG,*.MPG,*.MP2,*.MPV,*.MP4,*.M4P,*.M4V,*.AVI,*.MOV,*.OT,*.FLV'),
                                                   ('all files','*.*')))
    l1_ent.insert(END,file_path)
def convert():
    source_path=source.get()
    target_path=target.get()
    if not target_path:
        # If no target is specified, create a default name
        target_path = os.path.splitext(source_path)[0] + ".mp3"  # Change to .mp3 or desired format
    try:
        video = moviepy.VideoFileClip(source_path)
        aud = video.audio
        aud.write_audiofile(target_path)
    except Exception as e:
        print(f"An error occurred: {e}")

l=Label(root,text="Mp3 Converter",font=("Jokerman",30),bg="midnightblue",fg="white")
l.place(x=260,y=20)

l1=Label(root,text="Select Video:",font=("Bahnschrift",15,"bold"),bd=0,bg="lightblue")
l1.place(x=170,y=125)
source=StringVar()
l1_ent=Entry(root,textvariable=source,font=("Courier New",12))
l1_ent.place(x=310,y=125,width=310,height=27)
browse1=Button(root,text="🔍",font=(12),bg="lightblue",bd=0,command=openfile)
browse1.place(x=630,y=125,width=30,height=27)

target=StringVar()
l3=Label(root,text="New file name:",font=("Bahnschrift",15,"bold"),bd=0,bg="lightblue")
l3.place(x=170,y=195)
l3_ent=Entry(root,textvariable=target,font=("Courier New",12))
l3_ent.place(x=310,y=195,width=310,height=27)

conv=Button(root,text="Convert",font=("Bahnschrift",15,"bold"),bd=0,bg="lightblue",command=convert)
conv.place(x=380,y=260)

root.mainloop()